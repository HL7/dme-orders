package http://hl7.org/fhir/us/dme-orders/ImplementationGuide/post-acute-orders4;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PAOtask4 {

}
