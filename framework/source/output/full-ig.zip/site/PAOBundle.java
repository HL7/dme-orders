package http://hl7.org/fhir/us/dme-orders/implementationguide/Post-Acute-Orders3;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class PAOBundle {

}
